import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;

public class MatchingGame implements ActionListener
{


    LocalTime time = LocalTime.parse("00:00:00");
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("mm:ss");
    Random random=new Random();
    JFrame jFrame=new JFrame();
    JPanel timePanel=new JPanel();
    JPanel buttonPanel=new JPanel();
    JLabel timeLabel=new JLabel();
    JButton[][] board=new JButton[4][6];
    int boardValues[][]=new int[4][6];
    Color colors[]={Color.RED,Color.YELLOW,Color.GREEN,Color.MAGENTA,Color.PINK,Color.GREEN,Color.CYAN,Color.RED};
    int matchCounter=0;
    int clickCount=0;
    int matchValue[]=new int[3];
    String saveButtonLocation[]=new String[3];
    long startTime,endTime;

    public MatchingGame()
    {
        startTime=System.currentTimeMillis();
        timeLabel.setHorizontalAlignment(JLabel.CENTER);
        timeLabel.setText("Matching Game by Rizwan");
        timeLabel.setFont(new Font("",Font.BOLD,24));
        timeLabel.setOpaque(true);

        timePanel.setLayout(new BorderLayout());
        timePanel.setBounds(0,0,600,50);
        timePanel.add(timeLabel,BorderLayout.NORTH);

        buttonPanel.setLayout(new GridLayout(6,4));
        buttonPanel.setBackground(new Color(50,50,50));
        buttonPanel.setBounds(0,50,600,500);

        for (int i=0;i<4;i++)
        {
            for (int j=0;j<6;j++)
            {
                board[i][j]=new JButton();
                buttonPanel.add(board[i][j]);
                board[i][j].setBackground(Color.GRAY);
                board[i][j].setFocusable(false);
                board[i][j].setFont(new Font("Arial", Font.BOLD, 18));
                board[i][j].addActionListener(this);
            }
        }


        jFrame.add(timePanel,BorderLayout.NORTH);



        jFrame.add(buttonPanel);

        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setSize(700,600);
        jFrame.setLayout(new BorderLayout());
        jFrame.setVisible(true);
        jFrame.setTitle("Match 3 Game");

        setRandomNumberToTiles();
    }

    public void setRandomNumberToTiles()
    {
        ArrayList<Integer> list=new ArrayList<>();
        for (int i=0;i<12;)
        {
            int x= random.nextInt(9)+1;

            if(list.contains(x))
            {
                continue;
            }
            else
            {
                list.add(x);
                i++;
            }
            int counter=0;
            while (counter!=2)
            {
                int r= random.nextInt(4);
                int c=random.nextInt(6);

                if(boardValues[r][c]==0)
                {
                    boardValues[r][c]=x;
                    counter++;
                }

            }

        }
        
    }


    @Override
    public void actionPerformed(ActionEvent e)
    {
        for (int r=0;r<4;r++)
        {
            for (int c=0;c<6;c++)
            {
                if(matchCounter==12)
                {
                    return;
                }
                if(e.getSource()==board[r][c])
                {
                    board[r][c].setText(Integer.toString(boardValues[r][c]));
                    board[r][c].setBackground(colors[matchCounter]);
                    matchValue[clickCount]=boardValues[r][c];
                    saveButtonLocation[clickCount]=r+","+c;
                    clickCount++;
                    if(clickCount==2)
                    {
                        clickCount=0;
                        checkMatch();

                    }
                }
            }
        }
    }

    public void checkMatch()
    {
        if(matchValue[0]==matchValue[1])
        {
            matchCounter++;
            if(matchCounter==12)
            {
                endTime=System.currentTimeMillis();
                SimpleDateFormat formatter= new SimpleDateFormat("mm:ss ");
                Date date = new Date(endTime-startTime);

                timeLabel.setText("Time tack to check all matches: "+formatter.format(date));
            }
        }
        else
        {
            for (int i=0;i<2;i++)
            {
                String arrays[]=saveButtonLocation[i].split(",");
                int r=Integer.parseInt(arrays[0]);
                int c=Integer.parseInt(arrays[1]);
                board[r][c].setBackground(Color.GRAY);
                board[r][c].setText("");
            }
        }
    }
    public static void main(String[] args)
    {
        new MatchingGame();
    }
}
